# node-express-mongodb-html-demo-1

The example shows the basic usage of the components used in a NodeJS web app - the front end (browser code with HTML, CSS and JavaScript) and the backend (the web server and database access code using NodeJS, ExpressJS and MongoDB NodeJS Driver APIs). The app has functionality to query (a GET request with a read database operation), add data (a POST request with a database insert operation) and delete data (a DELETE request with database delete operation).
